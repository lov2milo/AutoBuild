# AutoBuild (Fabric 1.21.11)

Mod client tự xây schematic Litematica: tự xoay hướng (AutoRotate), đặt nhanh, dọn block sai, dùng block đỡ tạm, tự đi.

## Build bằng GitHub Actions (không cần PC)
1. Push toàn bộ thư mục này lên repo GitHub (nhánh `main`).
2. Vào tab **Actions** → chạy xong → tải artifact **autobuild-jar** → giải nén lấy file `.jar`.
3. Bỏ jar vào `mods/` cùng Fabric API + Litematica + MaLiLib (Baritone tuỳ chọn, để tự đi mượt hơn).

## Dùng
1. Litematica: load schematic, đặt placement (và chọn layer nếu muốn xây từng lớp).
2. Cầm sẵn nguyên liệu trong túi đồ, đứng gần vùng xây.
3. Gõ `/autobuild start` (hoặc `/ab start`). Dừng: `/autobuild stop`.

## Lệnh
| Lệnh | Tác dụng |
|---|---|
| `/autobuild` | xem trạng thái + cài đặt |
| `start` / `stop` / `toggle` | bật/tắt |
| `rotate [on/off]` | AutoRotate (gửi gói xoay để ra đúng hướng observer, stairs...) |
| `walk [on/off]` | tự đi tới chỗ cần xây (dùng Baritone nếu có) |
| `clear [on/off]` | phá block sai rồi đặt lại |
| `extra [on/off]` | phá block thừa (schematic là không khí) |
| `layer [on/off]` | chỉ làm trong layer Litematica đang hiện |
| `support [on/off]` | block đỡ tạm (cobblestone/dirt/netherrack...) cho block lơ lửng |
| `range <1-6>` | tầm với |
| `speed <1-20>` | số block mỗi tick |
| `reset` | xoá danh sách ô bị bỏ qua |

Cài đặt lưu ở `config/autobuild.json`.
