package dev.autobuild;

import net.minecraft.world.World;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/** Cầu nối tới Litematica bằng reflection (không cần Litematica lúc biên dịch). */
public final class Schem {
    private Schem() {}

    private static Method getWorld;
    private static Method getLayerRange;
    private static Method inRange;

    /** Thế giới schematic của Litematica (WorldSchematic kế thừa World), hoặc null. */
    public static World world() {
        try {
            if (getWorld == null) {
                getWorld = Class.forName("fi.dy.masa.litematica.world.SchematicWorldHandler")
                        .getMethod("getSchematicWorld");
            }
            Object o = getWorld.invoke(null);
            return o instanceof World w ? w : null;
        } catch (Throwable t) {
            return null;
        }
    }

    /** Hộp bao {minX,minY,minZ,maxX,maxY,maxZ} của các placement đang bật. */
    public static List<int[]> boxes() {
        List<int[]> out = new ArrayList<>();
        try {
            Class<?> dm = Class.forName("fi.dy.masa.litematica.data.DataManager");
            Object mgr = dm.getMethod("getSchematicPlacementManager").invoke(null);
            Object list = call(mgr, "getAllSchematicsPlacements", "getAllSchematicPlacements");
            if (!(list instanceof Iterable<?> it)) return out;
            for (Object p : it) {
                Object enabled = call(p, "isEnabled");
                if (enabled instanceof Boolean b && !b) continue;
                Object box = call(p, "getEclosingBox", "getEnclosingBox");
                if (box == null) continue;
                out.add(new int[]{
                        geti(box, "minX"), geti(box, "minY"), geti(box, "minZ"),
                        geti(box, "maxX"), geti(box, "maxY"), geti(box, "maxZ")});
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    /** Ô (x,y,z) có nằm trong layer Litematica đang hiển thị không. */
    public static boolean inLayer(int x, int y, int z) {
        try {
            if (getLayerRange == null) {
                getLayerRange = Class.forName("fi.dy.masa.litematica.data.DataManager")
                        .getMethod("getRenderLayerRange");
            }
            Object lr = getLayerRange.invoke(null);
            if (lr == null) return true;
            if (inRange == null) {
                inRange = lr.getClass().getMethod("isPositionWithinRange", int.class, int.class, int.class);
            }
            return (Boolean) inRange.invoke(lr, x, y, z);
        } catch (Throwable t) {
            return true;
        }
    }

    private static Object call(Object target, String... names) throws Exception {
        for (String n : names) {
            try {
                return target.getClass().getMethod(n).invoke(target);
            } catch (NoSuchMethodException ignored) {
            }
        }
        return null;
    }

    private static int geti(Object box, String name) throws Exception {
        try {
            return box.getClass().getField(name).getInt(box);
        } catch (NoSuchFieldException ignored) {
        }
        String getter = "get" + Character.toUpperCase(name.charAt(0)) + name.substring(1);
        for (String n : new String[]{getter, name}) {
            try {
                return ((Number) box.getClass().getMethod(n).invoke(box)).intValue();
            } catch (NoSuchMethodException ignored) {
            }
        }
        throw new NoSuchFieldException(name);
    }
}
