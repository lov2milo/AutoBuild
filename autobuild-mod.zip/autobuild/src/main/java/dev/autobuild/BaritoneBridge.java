package dev.autobuild;

import net.minecraft.util.math.BlockPos;

/** Gọi Baritone bằng reflection (tuỳ chọn). Không có Baritone thì available() = false. */
final class BaritoneBridge {
    private BaritoneBridge() {}

    private static Boolean ok;

    static boolean available() {
        if (ok == null) {
            try {
                Class.forName("baritone.api.BaritoneAPI");
                ok = true;
            } catch (Throwable t) {
                ok = false;
            }
        }
        return ok;
    }

    private static Object baritone() throws Exception {
        Object provider = Class.forName("baritone.api.BaritoneAPI").getMethod("getProvider").invoke(null);
        return Class.forName("baritone.api.IBaritoneProvider").getMethod("getPrimaryBaritone").invoke(provider);
    }

    static boolean goNear(BlockPos pos, int range) {
        try {
            Object b = baritone();
            Object goal = Class.forName("baritone.api.pathing.goals.GoalNear")
                    .getConstructor(BlockPos.class, int.class).newInstance(pos, range);
            Object proc = Class.forName("baritone.api.IBaritone").getMethod("getCustomGoalProcess").invoke(b);
            Class.forName("baritone.api.process.ICustomGoalProcess")
                    .getMethod("setGoalAndPath", Class.forName("baritone.api.pathing.goals.Goal"))
                    .invoke(proc, goal);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    static boolean pathing() {
        try {
            Object pb = Class.forName("baritone.api.IBaritone").getMethod("getPathingBehavior").invoke(baritone());
            return (Boolean) Class.forName("baritone.api.behavior.IPathingBehavior").getMethod("isPathing").invoke(pb);
        } catch (Throwable t) {
            return false;
        }
    }

    static void cancel() {
        try {
            Object pb = Class.forName("baritone.api.IBaritone").getMethod("getPathingBehavior").invoke(baritone());
            Class.forName("baritone.api.behavior.IPathingBehavior").getMethod("cancelEverything").invoke(pb);
        } catch (Throwable ignored) {
        }
    }
}
