package dev.autobuild;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** Tự đi: dùng Baritone nếu có (reflection), không thì đi thẳng đơn giản (nhảy khi vướng, dừng nếu nguy hiểm). */
final class Walker {
    private Vec3d goal;
    private Vec3d lastPos;
    private int stuckChecks;
    private int age;
    private int lastBaritone = -999;
    private BlockPos bTarget;
    private boolean baritoneBroken;
    private boolean stuck;

    /** Đã bị kẹt/không an toàn kể từ lần hỏi trước? */
    boolean consumeStuck() {
        boolean s = stuck;
        stuck = false;
        return s;
    }

    void goTo(MinecraftClient mc, BlockPos t, double range) {
        if (BaritoneBridge.available() && !baritoneBroken) {
            if (t.equals(bTarget) && BaritoneBridge.pathing()) return;
            if (age - lastBaritone <= 40) return;
            lastBaritone = age;
            bTarget = t;
            if (BaritoneBridge.goNear(t, Math.max(2, (int) (range - 1.5)))) return;
            baritoneBroken = true;
        }
        Vec3d g = new Vec3d(t.getX() + 0.5, t.getY(), t.getZ() + 0.5);
        if (goal == null || goal.squaredDistanceTo(g) > 1.0) {
            goal = g;
            lastPos = null;
            stuckChecks = 0;
        }
    }

    /** Gọi mỗi tick. */
    void update(MinecraftClient mc) {
        age++;
        ClientPlayerEntity p = mc.player;
        if (goal == null || p == null || mc.world == null) {
            if (goal == null) release(mc);
            return;
        }
        double dx = goal.x - p.getX();
        double dz = goal.z - p.getZ();
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.1) {
            goal = null;
            release(mc);
            return;
        }
        if (lastPos == null) lastPos = new Vec3d(p.getX(), p.getY(), p.getZ());
        if (age % 20 == 0) {
            Vec3d now = new Vec3d(p.getX(), p.getY(), p.getZ());
            if (now.squaredDistanceTo(lastPos) < 0.04) {
                if (++stuckChecks >= 3) {
                    abort(mc);
                    return;
                }
            } else {
                stuckChecks = 0;
            }
            lastPos = now;
        }
        BlockPos ahead = BlockPos.ofFloored(p.getX() + dx / len * 0.9, p.getY(), p.getZ() + dz / len * 0.9);
        if (!safe(mc.world, ahead)) {
            abort(mc);
            return;
        }
        p.setYaw((float) Math.toDegrees(Math.atan2(-dx, dz)));
        mc.options.forwardKey.setPressed(true);
        mc.options.jumpKey.setPressed(p.horizontalCollision && p.isOnGround());
    }

    /** Bước sang ô trống gần đó (khi chính người chơi đang đứng chắn chỗ cần đặt). */
    void stepAside(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        BlockPos o = p.getBlockPos();
        int[][] dirs = {{2, 0}, {-2, 0}, {0, 2}, {0, -2}, {2, 2}, {2, -2}, {-2, 2}, {-2, -2}};
        for (int[] d : dirs) {
            for (int dy = 0; dy >= -1; dy--) {
                BlockPos f = o.add(d[0], dy, d[1]);
                if (w.getBlockState(f).getCollisionShape(w, f).isEmpty()
                        && w.getBlockState(f.up()).getCollisionShape(w, f.up()).isEmpty()
                        && !w.getBlockState(f.down()).isAir()
                        && safe(w, f)) {
                    goal = new Vec3d(f.getX() + 0.5, f.getY(), f.getZ() + 0.5);
                    lastPos = null;
                    stuckChecks = 0;
                    return;
                }
            }
        }
    }

    void stop(MinecraftClient mc) {
        goal = null;
        if (mc != null && mc.options != null) release(mc);
        if (bTarget != null) {
            BaritoneBridge.cancel();
            bTarget = null;
        }
    }

    private void abort(MinecraftClient mc) {
        goal = null;
        stuck = true;
        release(mc);
    }

    private static void release(MinecraftClient mc) {
        if (mc.options == null) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
    }

    private static boolean safe(ClientWorld w, BlockPos feet) {
        for (int i = 0; i <= 3; i++) {
            BlockState s = w.getBlockState(feet.down(i));
            if (s.isOf(Blocks.LAVA) || s.isOf(Blocks.FIRE) || s.isOf(Blocks.MAGMA_BLOCK) || s.isOf(Blocks.CACTUS)) {
                return false;
            }
            if (!s.isAir() && s.getFluidState().isEmpty()) return true;
        }
        return false;
    }
}
