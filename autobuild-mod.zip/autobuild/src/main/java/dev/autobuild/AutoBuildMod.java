package dev.autobuild;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.tree.LiteralCommandNode;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.function.Consumer;
import java.util.function.Supplier;

/** AutoBuild: tự xây schematic Litematica. Lệnh: /autobuild (hoặc /ab) */
public final class AutoBuildMod implements ClientModInitializer {
    public static Config cfg;
    public static Builder builder;

    @Override
    public void onInitializeClient() {
        cfg = Config.load();
        builder = new Builder(cfg);
        ClientTickEvents.END_CLIENT_TICK.register(builder::tick);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> register(dispatcher));
    }

    private static void reply(FabricClientCommandSource s, String text) {
        s.sendFeedback(Text.literal(text));
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> flag(
            String name, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
        return ClientCommandManager.literal(name)
                .executes(c -> {
                    set.accept(!get.get());
                    cfg.save();
                    reply(c.getSource(), label + ": " + (get.get() ? "BẬT" : "TẮT"));
                    return 1;
                })
                .then(ClientCommandManager.argument("bat", BoolArgumentType.bool())
                        .executes(c -> {
                            set.accept(BoolArgumentType.getBool(c, "bat"));
                            cfg.save();
                            reply(c.getSource(), label + ": " + (get.get() ? "BẬT" : "TẮT"));
                            return 1;
                        }));
    }

    private static void register(CommandDispatcher<FabricClientCommandSource> d) {
        LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("autobuild")
                .executes(c -> {
                    reply(c.getSource(), builder.statusLine());
                    return 1;
                })
                .then(ClientCommandManager.literal("start").executes(c -> {
                    builder.start();
                    reply(c.getSource(), "AutoBuild: BẮT ĐẦU");
                    return 1;
                }))
                .then(ClientCommandManager.literal("stop").executes(c -> {
                    builder.stop(MinecraftClient.getInstance());
                    reply(c.getSource(), "AutoBuild: DỪNG");
                    return 1;
                }))
                .then(ClientCommandManager.literal("toggle").executes(c -> {
                    if (builder.isActive()) {
                        builder.stop(MinecraftClient.getInstance());
                        reply(c.getSource(), "AutoBuild: DỪNG");
                    } else {
                        builder.start();
                        reply(c.getSource(), "AutoBuild: BẮT ĐẦU");
                    }
                    return 1;
                }))
                .then(ClientCommandManager.literal("reset").executes(c -> {
                    builder.resetTries();
                    reply(c.getSource(), "Đã xoá danh sách ô bị bỏ qua");
                    return 1;
                }))
                .then(flag("rotate", "AutoRotate", () -> cfg.rotate, v -> cfg.rotate = v))
                .then(flag("walk", "Tự đi", () -> cfg.walk, v -> cfg.walk = v))
                .then(flag("clear", "Phá block sai", () -> cfg.clearWrong, v -> cfg.clearWrong = v))
                .then(flag("extra", "Phá block thừa", () -> cfg.clearExtra, v -> cfg.clearExtra = v))
                .then(flag("layer", "Chỉ layer đang hiện", () -> cfg.layerOnly, v -> cfg.layerOnly = v))
                .then(flag("support", "Block đỡ tạm", () -> cfg.support, v -> cfg.support = v))
                .then(ClientCommandManager.literal("range")
                        .then(ClientCommandManager.argument("n", DoubleArgumentType.doubleArg(1.0, 6.0))
                                .executes(c -> {
                                    cfg.range = DoubleArgumentType.getDouble(c, "n");
                                    cfg.save();
                                    reply(c.getSource(), "Tầm với: " + cfg.range);
                                    return 1;
                                })))
                .then(ClientCommandManager.literal("speed")
                        .then(ClientCommandManager.argument("n", IntegerArgumentType.integer(1, 20))
                                .executes(c -> {
                                    cfg.perTick = IntegerArgumentType.getInteger(c, "n");
                                    cfg.save();
                                    reply(c.getSource(), "Tốc độ: " + cfg.perTick + " block/tick");
                                    return 1;
                                })));
        LiteralCommandNode<FabricClientCommandSource> node = d.register(root);
        d.register(ClientCommandManager.literal("ab").executes(c -> {
            reply(c.getSource(), builder.statusLine());
            return 1;
        }).redirect(node));
    }
}
