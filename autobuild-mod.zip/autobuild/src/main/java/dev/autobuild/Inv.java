package dev.autobuild;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.slot.SlotActionType;

/** Quản lý hotbar / túi đồ. */
final class Inv {
    private Inv() {}

    /** Block rẻ tiền dùng làm điểm tựa tạm. */
    static final Block[] SCRAP = {
            Blocks.COBBLESTONE, Blocks.COBBLED_DEEPSLATE, Blocks.NETHERRACK, Blocks.DIRT, Blocks.STONE,
            Blocks.ANDESITE, Blocks.DIORITE, Blocks.GRANITE, Blocks.TUFF, Blocks.OAK_PLANKS
    };

    static boolean has(MinecraftClient mc, Item item) {
        PlayerInventory inv = mc.player.getInventory();
        for (int i = 0; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty() && s.isOf(item)) return true;
        }
        return false;
    }

    static Block findScrap(MinecraftClient mc) {
        for (Block b : SCRAP) {
            if (has(mc, b.asItem())) return b;
        }
        return null;
    }

    /** Đưa item vào hotbar (hoán đổi từ túi đồ nếu cần) và chọn nó. */
    static boolean select(MinecraftClient mc, Item item) {
        ClientPlayerEntity p = mc.player;
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < 9; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty() && s.isOf(item)) {
                if (inv.getSelectedSlot() != i) inv.setSelectedSlot(i);
                return true;
            }
        }
        for (int i = 9; i < 36; i++) {
            ItemStack s = inv.getStack(i);
            if (!s.isEmpty() && s.isOf(item)) {
                int hb = freeHotbar(inv);
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, hb, SlotActionType.SWAP, p);
                inv.setSelectedSlot(hb);
                return true;
            }
        }
        return false;
    }

    /** Chọn dụng cụ đào nhanh nhất trong hotbar cho block này. */
    static void selectBestTool(MinecraftClient mc, BlockState state) {
        PlayerInventory inv = mc.player.getInventory();
        int best = inv.getSelectedSlot();
        float bestSpeed = inv.getStack(best).getMiningSpeedMultiplier(state);
        for (int i = 0; i < 9; i++) {
            float sp = inv.getStack(i).getMiningSpeedMultiplier(state);
            if (sp > bestSpeed + 0.01f) {
                best = i;
                bestSpeed = sp;
            }
        }
        if (best != inv.getSelectedSlot()) inv.setSelectedSlot(best);
    }

    private static int freeHotbar(PlayerInventory inv) {
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isEmpty()) return i;
        }
        return inv.getSelectedSlot();
    }
}
