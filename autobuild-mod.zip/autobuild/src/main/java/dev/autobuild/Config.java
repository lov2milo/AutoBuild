package dev.autobuild;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Cài đặt, lưu ở config/autobuild.json */
public final class Config {
    public boolean rotate = true;       // AutoRotate: xoay hướng (gói tin) trước khi đặt
    public boolean walk = false;        // tự đi tới chỗ cần xây
    public boolean clearWrong = true;   // phá block sai loại/sai hướng rồi đặt lại
    public boolean clearExtra = false;  // phá block thừa (schematic là không khí)
    public boolean layerOnly = true;    // chỉ làm trong layer Litematica đang hiển thị
    public boolean support = true;      // dùng block đỡ tạm cho block lơ lửng
    public double range = 4.5;          // tầm với (block)
    public int perTick = 4;             // số block đặt mỗi tick
    public int cooldown = 0;            // tick nghỉ giữa các đợt
    public int scanBudget = 20000;      // số ô quét toàn cục mỗi tick

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("autobuild.json");
    }

    public static Config load() {
        try {
            Path f = file();
            if (Files.exists(f)) {
                Config c = GSON.fromJson(Files.readString(f), Config.class);
                if (c != null) {
                    c.sanitize();
                    return c;
                }
            }
        } catch (Exception ignored) {
        }
        return new Config();
    }

    public void save() {
        try {
            Files.writeString(file(), GSON.toJson(this));
        } catch (Exception ignored) {
        }
    }

    private void sanitize() {
        range = Math.max(1.0, Math.min(6.0, range));
        perTick = Math.max(1, Math.min(20, perTick));
        cooldown = Math.max(0, Math.min(40, cooldown));
        scanBudget = Math.max(2000, Math.min(200000, scanBudget));
    }
}
