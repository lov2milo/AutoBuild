package dev.autobuild;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.enums.BedPart;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.state.property.Properties;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Vòng lặp chính: quét schematic, đặt block, dọn block sai, đi tới chỗ tiếp theo. */
public final class Builder {
    private enum Kind { NONE, PLACE, CLEAR_WRONG, CLEAR_EXTRA }

    private static final int MAX_TRIES = 8;

    private final Config cfg;
    private final Walker walker = new Walker();

    private boolean active;
    private int wait;
    private int tickCount;
    private int idle;
    private int msgAge;
    private String status = "Tắt";

    // vùng xây (hộp bao các placement Litematica)
    private List<int[]> boxes = new ArrayList<>();
    private boolean boxesReliable = true;
    private int boxAge = 999;

    // quét toàn cục tăng dần
    private int sBox;
    private long sCur;
    private int sCount;
    private int sBestY;
    private double sBestD;
    private BlockPos sBest;
    private int remaining = -1;
    private int sweeps;
    private BlockPos target;

    private final Map<Long, Integer> tries = new HashMap<>();
    private final Set<Long> temp = new LinkedHashSet<>();
    private BlockPos breaking;

    public Builder(Config cfg) {
        this.cfg = cfg;
        resetSweep();
    }

    public boolean isActive() {
        return active;
    }

    public void start() {
        active = true;
        tries.clear();
        temp.clear();
        remaining = -1;
        sweeps = 0;
        target = null;
        breaking = null;
        idle = 0;
        wait = 0;
        boxAge = 999;
        resetSweep();
        status = "Đang chạy";
    }

    public void stop(MinecraftClient mc) {
        active = false;
        breaking = null;
        walker.stop(mc);
        if (mc != null && mc.interactionManager != null) mc.interactionManager.cancelBlockBreaking();
        status = "Tắt";
    }

    public void resetTries() {
        tries.clear();
    }

    public String statusLine() {
        return "AutoBuild " + (active ? "ĐANG CHẠY" : "TẮT") + " | " + status
                + (remaining >= 0 ? " | còn " + remaining : "")
                + " | rotate=" + onOff(cfg.rotate) + " walk=" + onOff(cfg.walk)
                + " clear=" + onOff(cfg.clearWrong) + " extra=" + onOff(cfg.clearExtra)
                + " layer=" + onOff(cfg.layerOnly) + " support=" + onOff(cfg.support)
                + " range=" + cfg.range + " speed=" + cfg.perTick;
    }

    private static String onOff(boolean b) {
        return b ? "bật" : "tắt";
    }

    // ------------------------------------------------------------------ tick

    public void tick(MinecraftClient mc) {
        if (!active) return;
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        if (p == null || w == null || mc.interactionManager == null) return;
        if (mc.currentScreen != null) return;
        tickCount++;
        walker.update(mc);

        World sw = Schem.world();
        if (sw == null) {
            show(mc, "Chưa có schematic (Litematica: load + đặt schematic)");
            return;
        }
        if (++boxAge >= 20) {
            refreshBoxes(p);
            boxAge = 0;
        }
        if (tickCount % 600 == 0) tries.clear();
        cleanTemp(w);
        sweep(p, sw, w);
        if (walker.consumeStuck() && target != null) {
            tries.merge(target.asLong(), MAX_TRIES, Integer::sum);
            target = null;
        }
        if (wait > 0) {
            wait--;
            return;
        }

        // ---- quét cục bộ trong tầm với ----
        final Vec3d eye = Placer.eye(p);
        BlockPos o = p.getBlockPos();
        int r = (int) Math.ceil(cfg.range) + 1;
        double lim = (cfg.range + 0.9) * (cfg.range + 0.9);
        List<BlockPos> places = new ArrayList<>();
        List<BlockPos> clears = new ArrayList<>();
        BlockPos.Mutable m = new BlockPos.Mutable();
        for (int dy = -r; dy <= r; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                for (int dz = -r; dz <= r; dz++) {
                    m.set(o.getX() + dx, o.getY() + dy, o.getZ() + dz);
                    if (eye.squaredDistanceTo(m.getX() + 0.5, m.getY() + 0.5, m.getZ() + 0.5) > lim) continue;
                    Kind k = classify(m, sw, w);
                    if (k == Kind.PLACE) places.add(m.toImmutable());
                    else if (k != Kind.NONE) clears.add(m.toImmutable());
                }
            }
        }
        places.sort(Comparator.<BlockPos>comparingInt(BlockPos::getY)
                .thenComparingDouble(b -> eye.squaredDistanceTo(Vec3d.ofCenter(b))));

        // ---- 1. đặt block ----
        int done = 0;
        BlockPos floating = null;
        Item missing = null;
        boolean blocked = false;
        for (BlockPos pos : places) {
            if (done >= cfg.perTick) break;
            BlockState want = sw.getBlockState(pos);
            Placer.Plan plan = Placer.solve(mc, pos, want, cfg);
            if (plan == null) {
                switch (Placer.lastReason) {
                    case NO_CLICK -> {
                        if (floating == null) floating = pos;
                    }
                    case ENTITY -> blocked = true;
                    case NO_MATCH, NO_ITEM -> bump(pos, 3);
                    default -> {
                    }
                }
                continue;
            }
            Placer.Result res = Placer.place(mc, plan);
            if (res == Placer.Result.MISSING) {
                missing = plan.item();
                continue;
            }
            bump(pos, 1);
            if (res == Placer.Result.OK) done++;
        }
        if (done > 0) {
            wait = cfg.cooldown;
            idle = 0;
            show(mc, "Đang đặt block");
            return;
        }
        if (missing != null) show(mc, "Thiếu: " + Placer.nameOf(missing));

        // ---- 2. block đỡ tạm cho block lơ lửng ----
        if (floating != null && cfg.support && placeSupport(mc, sw, w, floating)) {
            idle = 0;
            show(mc, "Đặt block đỡ tạm");
            return;
        }

        // ---- 3. dọn block sai / thừa / block đỡ tạm ----
        if (!clears.isEmpty()) {
            clears.sort(Comparator.comparingDouble(b -> eye.squaredDistanceTo(Vec3d.ofCenter(b))));
            BlockPos c = (breaking != null && clears.contains(breaking)) ? breaking : clears.get(0);
            if (Placer.mine(mc, c, cfg)) {
                breaking = c;
                idle = 0;
                show(mc, "Đang dọn block");
                return;
            }
            bump(c, 2);
            breaking = null;
        } else if (breaking != null) {
            mc.interactionManager.cancelBlockBreaking();
            breaking = null;
        }
        if (missing != null) return;

        // ---- 4. hết việc trong tầm với ----
        if (sweeps >= 1 && remaining == 0 && temp.isEmpty()) {
            stop(mc);
            mc.inGameHud.getChatHud().addMessage(Text.literal("AutoBuild: xây xong schematic!"));
            return;
        }
        if (target == null) {
            show(mc, "Đang quét schematic...");
            return;
        }
        double need = cfg.range - 0.5;
        boolean inReach = eye.squaredDistanceTo(Vec3d.ofCenter(target)) <= need * need;
        if (inReach) {
            if (blocked) walker.stepAside(mc);
            if (++idle > 40) {
                tries.merge(target.asLong(), MAX_TRIES, Integer::sum);
                target = null;
                idle = 0;
            }
            show(mc, "Chờ...");
        } else if (cfg.walk) {
            double hx = target.getX() + 0.5 - p.getX();
            double hz = target.getZ() + 0.5 - p.getZ();
            if (hx * hx + hz * hz < 4.0 && ++idle > 60) {
                // đã tới nơi mà vẫn quá cao/thấp -> bỏ qua mục tiêu này
                tries.merge(target.asLong(), MAX_TRIES, Integer::sum);
                target = null;
                idle = 0;
            } else {
                walker.goTo(mc, target, cfg.range);
                show(mc, "Đang đi tới " + target.toShortString());
            }
        } else {
            show(mc, "Hãy đi tới " + target.toShortString());
        }
    }

    // ------------------------------------------------------------- phân loại

    private Kind classify(BlockPos pos, World sw, ClientWorld w) {
        BlockState want = sw.getBlockState(pos);
        BlockState have = w.getBlockState(pos);
        long key = pos.asLong();
        boolean isTemp = temp.contains(key);
        if (want == have && !isTemp) return Kind.NONE;
        if (!isTemp && !inAnyBox(pos)) return Kind.NONE;
        if (tries.getOrDefault(key, 0) >= MAX_TRIES) return Kind.NONE;

        Kind k;
        if (isTemp) {
            k = have.isAir() ? Kind.NONE : Kind.CLEAR_EXTRA;
        } else if (want.isAir()) {
            if (have.isAir() || have.getBlock() instanceof FluidBlock || !cfg.clearExtra || !boxesReliable) {
                return Kind.NONE;
            }
            k = Kind.CLEAR_EXTRA;
        } else {
            if (skipPart(want) || Placer.matches(want, have)) return Kind.NONE;
            if (have.isAir() || have.isReplaceable() || isSlabMerge(want, have)) k = Kind.PLACE;
            else if (cfg.clearWrong) k = Kind.CLEAR_WRONG;
            else return Kind.NONE;
        }
        if (k == Kind.NONE) return Kind.NONE;
        if (!isTemp && k != Kind.PLACE && have.getHardness(w, pos) < 0) return Kind.NONE;
        if (!isTemp && cfg.layerOnly && !Schem.inLayer(pos.getX(), pos.getY(), pos.getZ())) return Kind.NONE;
        return k;
    }

    /** Nửa trên của cửa/cây cao, đầu giường: tự có khi đặt nửa dưới/chân. */
    private static boolean skipPart(BlockState s) {
        if (s.contains(Properties.DOUBLE_BLOCK_HALF) && s.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER) {
            return true;
        }
        return s.contains(Properties.BED_PART) && s.get(Properties.BED_PART) == BedPart.HEAD;
    }

    private static boolean isSlabMerge(BlockState want, BlockState have) {
        return want.getBlock() == have.getBlock()
                && want.contains(Properties.SLAB_TYPE) && have.contains(Properties.SLAB_TYPE)
                && want.get(Properties.SLAB_TYPE) == SlabType.DOUBLE
                && have.get(Properties.SLAB_TYPE) != SlabType.DOUBLE;
    }

    private boolean inAnyBox(BlockPos p) {
        int x = p.getX();
        int y = p.getY();
        int z = p.getZ();
        for (int[] b : boxes) {
            if (x >= b[0] && x <= b[3] && y >= b[1] && y <= b[4] && z >= b[2] && z <= b[5]) return true;
        }
        return false;
    }

    private void bump(BlockPos pos, int n) {
        tries.merge(pos.asLong(), n, Integer::sum);
    }

    // ----------------------------------------------------------------- hộp bao

    private void refreshBoxes(ClientPlayerEntity p) {
        List<int[]> b = Schem.boxes();
        boolean reliable = !b.isEmpty();
        if (!reliable) {
            // không đọc được vùng placement: chỉ làm quanh người chơi, không phá block thừa, không tự đi
            int r = (int) Math.ceil(cfg.range) + 2;
            b = List.of(new int[]{p.getBlockX() - r, p.getBlockY() - r, p.getBlockZ() - r,
                    p.getBlockX() + r, p.getBlockY() + r, p.getBlockZ() + r});
        }
        boolean changed = reliable != boxesReliable || b.size() != boxes.size();
        if (!changed) {
            for (int i = 0; i < b.size(); i++) {
                if (!Arrays.equals(b.get(i), boxes.get(i))) {
                    changed = true;
                    break;
                }
            }
        }
        boxes = b;
        boxesReliable = reliable;
        if (changed) {
            resetSweep();
            if (!reliable) {
                target = null;
                remaining = -1;
            }
        }
    }

    // ------------------------------------------------------------- quét toàn cục

    private void resetSweep() {
        sBox = 0;
        sCur = 0;
        sCount = 0;
        sBest = null;
        sBestY = Integer.MAX_VALUE;
        sBestD = Double.MAX_VALUE;
    }

    private void sweep(ClientPlayerEntity p, World sw, ClientWorld w) {
        if (!boxesReliable || boxes.isEmpty()) return;
        int budget = cfg.scanBudget;
        BlockPos.Mutable m = new BlockPos.Mutable();
        double px = p.getX();
        double pz = p.getZ();
        while (budget > 0 && sBox < boxes.size()) {
            int[] b = boxes.get(sBox);
            int sx = b[3] - b[0] + 1;
            int sy = b[4] - b[1] + 1;
            int sz = b[5] - b[2] + 1;
            long total = (long) sx * sy * sz;
            if (total <= 0) {
                sBox++;
                sCur = 0;
                continue;
            }
            while (budget > 0 && sCur < total) {
                long c = sCur++;
                budget--;
                int x = b[0] + (int) (c % sx);
                long rest = c / sx;
                int z = b[2] + (int) (rest % sz);
                int y = b[1] + (int) (rest / sz);
                m.set(x, y, z);
                if (classify(m, sw, w) == Kind.NONE) continue;
                sCount++;
                double dx = x + 0.5 - px;
                double dz = z + 0.5 - pz;
                double d = dx * dx + dz * dz;
                if (y < sBestY || (y == sBestY && d < sBestD)) {
                    sBestY = y;
                    sBestD = d;
                    sBest = m.toImmutable();
                }
            }
            if (sCur >= total) {
                sBox++;
                sCur = 0;
            }
        }
        if (sBox >= boxes.size()) {
            target = sBest;
            remaining = sCount;
            sweeps++;
            resetSweep();
        }
    }

    // --------------------------------------------------------------- block đỡ tạm

    private boolean placeSupport(MinecraftClient mc, World sw, ClientWorld w, BlockPos t) {
        Block scrap = Inv.findScrap(mc);
        if (scrap == null) {
            show(mc, "Thiếu block đỡ tạm (cobblestone/dirt/netherrack...)");
            return false;
        }
        // block cần điểm tựa vĩnh viễn (đuốc, nút...) thì không dùng đỡ tạm được
        if (!sw.getBlockState(t).canPlaceAt(w, t)) return false;
        for (Direction d : Direction.values()) {
            BlockPos s = t.offset(d);
            BlockState hs = w.getBlockState(s);
            if (!hs.isAir() && !hs.isReplaceable()) continue;
            if (!sw.getBlockState(s).isAir()) continue; // ô này thuộc schematic, để xây thật sau
            Placer.Plan sp = Placer.solve(mc, s, scrap.getDefaultState(), cfg);
            if (sp == null) continue;
            if (Placer.place(mc, sp) == Placer.Result.OK) {
                temp.add(s.asLong());
                return true;
            }
        }
        return false;
    }

    private void cleanTemp(ClientWorld w) {
        Iterator<Long> it = temp.iterator();
        while (it.hasNext()) {
            if (w.getBlockState(BlockPos.fromLong(it.next())).isAir()) it.remove();
        }
    }

    // ------------------------------------------------------------------- hiển thị

    private void show(MinecraftClient mc, String s) {
        status = s;
        if (++msgAge >= 5) {
            msgAge = 0;
            mc.inGameHud.setOverlayMessage(Text.literal("AutoBuild: " + s
                    + (remaining >= 0 ? "  |  còn " + remaining : "")), false);
        }
    }
}
