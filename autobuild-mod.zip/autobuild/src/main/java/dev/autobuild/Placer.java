package dev.autobuild;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Lõi đặt/phá block.
 * Ý tưởng "AutoRotate": với mỗi block, thử mô phỏng chính hàm getPlacementState của game
 * với nhiều góc nhìn (yaw/pitch) + vị trí click, chọn cái cho ra đúng trạng thái schematic,
 * rồi gửi gói xoay đó trước khi click.
 */
final class Placer {
    private Placer() {}

    enum Reason { OK, NO_ITEM, NO_CLICK, FAR, NO_MATCH, ENTITY }

    enum Result { OK, MISSING, REJECTED }

    record Plan(BlockPos click, Direction face, Vec3d hit, float yaw, float pitch, boolean rotate, Item item) {}

    private record Click(BlockPos pos, Direction face, Vec3d hit, double dist) {}

    static Reason lastReason = Reason.OK;

    /** Thuộc tính do môi trường/hàng xóm quyết định -> bỏ qua khi so sánh. */
    private static final Set<String> IGNORE = new HashSet<>(Arrays.asList(
            "powered", "lit", "open", "waterlogged", "distance", "persistent", "power", "locked",
            "triggered", "extended", "occupied", "in_wall", "bottom", "east", "west", "north", "south",
            "up", "down", "delay", "shape", "age", "level", "stage", "signal_fire", "eye", "conditional",
            "attached", "enabled", "inverted", "mode", "bites", "charges", "layers", "moisture", "hatch",
            "eggs", "pickles", "candles", "honey_level", "has_book", "has_record", "disarmed", "hinge"));

    static Vec3d eye(ClientPlayerEntity p) {
        return new Vec3d(p.getX(), p.getEyeY(), p.getZ());
    }

    static String nameOf(Item item) {
        return new ItemStack(item).getName().getString();
    }

    static boolean hasOrientation(BlockState s) {
        for (Property<?> pr : s.getProperties()) {
            if (!IGNORE.contains(pr.getName())) return true;
        }
        return false;
    }

    /** Hai trạng thái giống nhau ở các thuộc tính quan trọng (hướng, nửa, trục...) */
    static boolean matches(BlockState want, BlockState have) {
        if (want.getBlock() != have.getBlock()) return false;
        for (Property<?> pr : want.getProperties()) {
            if (IGNORE.contains(pr.getName()) || !have.contains(pr)) continue;
            Object a = want.get(pr);
            Object b = have.get(pr);
            if (!a.equals(b)) return false;
        }
        return true;
    }

    private static Plan fail(Reason r) {
        lastReason = r;
        return null;
    }

    /** Tìm cách đặt `want` vào `pos` trong tầm với. Trả null nếu không được (xem lastReason). */
    static Plan solve(MinecraftClient mc, BlockPos pos, BlockState want, Config cfg) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        Item item = want.getBlock().asItem();
        if (item == Items.AIR) return fail(Reason.NO_ITEM);
        ItemStack stack = new ItemStack(item);
        Vec3d eye = eye(p);
        double r2 = cfg.range * cfg.range;
        boolean orient = hasOrientation(want);

        List<Click> clicks = new ArrayList<>();
        boolean anyClickable = false;
        for (Direction d : Direction.values()) {
            BlockPos n = pos.offset(d);
            if (!clickable(w, n, d.getOpposite())) continue;
            anyClickable = true;
            addClicks(clicks, n, d.getOpposite(), orient, eye, r2);
        }
        // chạm vào chính block cùng loại (ghép slab...)
        if (w.getBlockState(pos).isOf(want.getBlock())) {
            anyClickable = true;
            for (Direction d : Direction.values()) addClicks(clicks, pos, d, false, eye, r2);
        }
        if (!anyClickable) return fail(Reason.NO_CLICK);
        if (clicks.isEmpty()) return fail(Reason.FAR);
        clicks.sort(Comparator.comparingDouble(Click::dist));

        List<float[]> rots = rotations(p, want, cfg, orient);
        ShapeContext sc = ShapeContext.of(p);
        boolean blocked = false;
        for (Click c : clicks) {
            BlockHitResult hit = new BlockHitResult(c.hit(), c.face(), c.pos(), false);
            for (float[] rot : rots) {
                BlockState res = simulate(p, stack, hit, want.getBlock(), pos, rot[0], rot[1]);
                if (res == null || !matches(want, res)) continue;
                if (!res.canPlaceAt(w, pos)) continue;
                if (!w.canPlace(res, pos, sc)) {
                    blocked = true;
                    continue;
                }
                lastReason = Reason.OK;
                return new Plan(c.pos(), c.face(), c.hit(), rot[0], rot[1], rot[2] > 0.5f, item);
            }
        }
        return fail(blocked ? Reason.ENTITY : Reason.NO_MATCH);
    }

    /** Danh sách góc nhìn thử: [yaw, pitch, cờ có-xoay]. Phần tử đầu = giữ nguyên góc hiện tại. */
    private static List<float[]> rotations(ClientPlayerEntity p, BlockState want, Config cfg, boolean orient) {
        List<float[]> l = new ArrayList<>();
        l.add(new float[]{p.getYaw(), p.getPitch(), 0f});
        if (cfg.rotate && orient) {
            for (float pitch : new float[]{0f, 90f, -90f}) {
                for (int k = 0; k < 4; k++) l.add(new float[]{k * 90f, pitch, 1f});
            }
            if (want.contains(Properties.ROTATION)) {
                for (int k = 0; k < 16; k++) l.add(new float[]{k * 22.5f, 0f, 1f});
            }
        }
        return l;
    }

    private static boolean clickable(ClientWorld w, BlockPos n, Direction face) {
        BlockState s = w.getBlockState(n);
        if (s.isAir() || s.isReplaceable() || !s.getFluidState().isEmpty()) return false;
        if (!s.isSideSolidFullSquare(w, n, face)) return false;
        if (s.createScreenHandlerFactory(w, n) != null) return false; // bàn chế tạo, v.v.
        return !(s.isOf(Blocks.NOTE_BLOCK) || s.isOf(Blocks.JUKEBOX));
    }

    private static void addClicks(List<Click> out, BlockPos clickPos, Direction face, boolean variants,
                                  Vec3d eye, double r2) {
        Vec3d base = Vec3d.ofCenter(clickPos).add(face.getOffsetX() * 0.5, face.getOffsetY() * 0.5, face.getOffsetZ() * 0.5);
        if (face.getAxis().isHorizontal()) {
            double[] fy = variants ? new double[]{0.5, 0.25, 0.75} : new double[]{0.5};
            for (double f : fy) {
                Vec3d hit = new Vec3d(base.x, clickPos.getY() + f, base.z);
                double d = eye.squaredDistanceTo(hit);
                if (d <= r2) out.add(new Click(clickPos, face, hit, d));
            }
        } else {
            double d = eye.squaredDistanceTo(base);
            if (d <= r2) out.add(new Click(clickPos, face, base, d));
        }
    }

    /** Mô phỏng đặt block với góc nhìn cho trước, không gửi gì lên server. */
    private static BlockState simulate(ClientPlayerEntity p, ItemStack stack, BlockHitResult hit, Block block,
                                       BlockPos target, float yaw, float pitch) {
        float oy = p.getYaw();
        float op = p.getPitch();
        p.setYaw(yaw);
        p.setPitch(pitch);
        try {
            ItemPlacementContext ctx = new ItemPlacementContext(p, Hand.MAIN_HAND, stack, hit);
            if (!ctx.getBlockPos().equals(target) || !ctx.canPlace()) return null;
            return block.getPlacementState(ctx);
        } catch (Throwable t) {
            return null;
        } finally {
            p.setYaw(oy);
            p.setPitch(op);
        }
    }

    /** Thực hiện kế hoạch đặt block. */
    static Result place(MinecraftClient mc, Plan plan) {
        ClientPlayerEntity p = mc.player;
        if (!Inv.select(mc, plan.item())) return Result.MISSING;
        float oy = p.getYaw();
        float op = p.getPitch();
        if (plan.rotate()) {
            p.setYaw(plan.yaw());
            p.setPitch(plan.pitch());
            p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                    plan.yaw(), plan.pitch(), p.isOnGround(), p.horizontalCollision));
        }
        BlockHitResult hit = new BlockHitResult(plan.hit(), plan.face(), plan.click(), false);
        ActionResult r = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, hit);
        boolean ok = r.isAccepted();
        if (ok) p.swingHand(Hand.MAIN_HAND);
        if (plan.rotate()) {
            p.setYaw(oy);
            p.setPitch(op);
        }
        return ok ? Result.OK : Result.REJECTED;
    }

    /** Phá 1 block (gọi mỗi tick tới khi vỡ). Trả false nếu không phá được/ngoài tầm. */
    static boolean mine(MinecraftClient mc, BlockPos pos, Config cfg) {
        ClientPlayerEntity p = mc.player;
        ClientWorld w = mc.world;
        BlockState st = w.getBlockState(pos);
        if (st.isAir()) return true;
        if (st.getHardness(w, pos) < 0) return false;
        Vec3d eye = eye(p);
        Direction face = null;
        Vec3d hit = null;
        double best = Double.MAX_VALUE;
        for (Direction d : Direction.values()) {
            Vec3d h = Vec3d.ofCenter(pos).add(d.getOffsetX() * 0.5, d.getOffsetY() * 0.5, d.getOffsetZ() * 0.5);
            double dd = eye.squaredDistanceTo(h);
            if (dd < best) {
                best = dd;
                face = d;
                hit = h;
            }
        }
        if (face == null || best > cfg.range * cfg.range) return false;
        Inv.selectBestTool(mc, st);
        if (cfg.rotate) sendLook(p, hit);
        if (p.isCreative()) {
            mc.interactionManager.attackBlock(pos, face);
        } else {
            mc.interactionManager.updateBlockBreakingProgress(pos, face);
        }
        p.swingHand(Hand.MAIN_HAND);
        return true;
    }

    private static void sendLook(ClientPlayerEntity p, Vec3d target) {
        Vec3d e = eye(p);
        double dx = target.x - e.x;
        double dy = target.y - e.y;
        double dz = target.z - e.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        p.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                yaw, pitch, p.isOnGround(), p.horizontalCollision));
    }
}
